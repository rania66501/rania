
document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.createElement('button');
  toggle.textContent = '🌙 Toggle Dark Mode';
  document.body.prepend(toggle);
  toggle.onclick = () => {
    document.body.classList.toggle('dark-mode');
  };
});
